package com.example.IMC;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImcApplicationTests {

	@Test
	void contextLoads() {
	}

}
