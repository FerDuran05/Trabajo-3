package com.example.IMC;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class ControladorWeb {
    // localhost:8080/calculadoraimc

    @GetMapping("/calculadoraimc")
    public String calculadora(
            @RequestParam(name = "Peso", required = true, defaultValue = "0") double Peso,
            @RequestParam(name = "Altura", required = true, defaultValue = "0") double Altura,
            @RequestParam(name = "IMC", required = true, defaultValue = "0") double IMC,
            Model model

    ) {
        model.addAttribute("Resultado", Math.round(IMC(Peso, Altura)));
        model.addAttribute("Estado", ObtenerEstado(IMC(Peso, Altura)));
        return "calculadoraimc";
    }

    public static double IMC(double Peso, double Altura) {

        return Peso / Math.pow(Altura, 2);

    }

    public String ObtenerEstado(double IMC) {

        String nivel = "";

        if (IMC >= 0 && IMC <= 18.5) {

            nivel = "Delgadez";

        }
        if (IMC >= 18.6 && IMC <= 24.9) {

            nivel = "Normal";

        }
        if (IMC >= 25 && IMC <= 34.9) {

            nivel = "Obesidad";

        }
        if (IMC >= 35 && IMC <= 49.9) {

            nivel = "Hiperobesidad";

        }
        if (IMC >= 50) {

            nivel = "Superobesidad";

        }

        return nivel;
    }
}

